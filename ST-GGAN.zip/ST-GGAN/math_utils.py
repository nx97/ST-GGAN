# -*- coding:utf-8 -*-
# GAT-TSP

import numpy as np
import pandas as pd


def z_score(x, mean, std):
    '''
    Z-score normalization

    Parameters
    ----------
    x: np.ndarray

    mean: float

    std: float

    Returns
    ----------
    np.ndarray

    '''

    return (x - mean) / std


def z_inverse(x, mean, std):
    '''
    The inverse of function z_score()

    Parameters
    ----------
    x: np.ndarray

    mean: float

    std: float

    Returns
    ----------
    np.ndarray

    '''
    return x * std + mean


def masked_mape_np(y_true, y_pred, null_val=0):
    '''
    MAPE
    '''
    with np.errstate(divide='ignore', invalid='ignore'):
        if np.isnan(null_val):
            mask = ~np.isnan(y_true)
        else:
            mask = np.not_equal(y_true, null_val)
        mask = mask.astype('float32')
        mask /= np.mean(mask)
        mape = np.abs(np.divide((y_pred - y_true).astype('float32'), y_true))
        mape = np.nan_to_num(mask * mape)
        return np.mean(mape) * 100


def RMSE(y_true, y_pred):
    '''
    Mean squared error
    '''
    return np.sqrt(np.mean((y_true - y_pred) ** 2))


def MAE(y_true, y_pred):
    '''
    Mean absolute error
    '''
    return np.mean(np.abs(y_true - y_pred))


def re_df(y_true,y_pred):
    a = np.mean(y_true,-1)
    b = np.mean(y_pred,-1)
    c = np.mean(a,-1)
    d = np.mean(b,-1)
    e = c.tolist()
    f = d.tolist()
    dic1 = {'y_true': e, 'y_pred': f}
    my_csv = pd.DataFrame(dic1)
    return my_csv