# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error,mean_absolute_error
import numpy.linalg as la
import math
from sklearn.svm import SVR
from statsmodels.tsa.arima_model import ARIMA
import matplotlib.pyplot as plt
import csv

def preprocess_data(data, time_len, rate, seq_len, pre_len):
    data1 = np.mat(data)   #创建矩阵
    train_size = int(time_len * rate)
    train_data = data1[0:train_size]    #随机抽取80%的数据作为训练集
    test_data = data1[train_size:time_len]    #剩下20%的数据作为测试集
    
    trainX, trainY, testX, testY = [], [], [], []
    for i in range(len(train_data) - seq_len - pre_len):
        a = train_data[i: i + seq_len + pre_len]
        trainX.append(a[0 : seq_len])
        trainY.append(a[seq_len : seq_len + pre_len])
    for i in range(len(test_data) - seq_len -pre_len):
        b = test_data[i: i + seq_len + pre_len]
        testX.append(b[0 : seq_len])
        testY.append(b[seq_len : seq_len + pre_len])
    return trainX, trainY, testX, testY
    
###### evaluation ######    误差平方函数
def evaluation(a,b):
    rmse = math.sqrt(mean_squared_error(a,b))
    mae = mean_absolute_error(a, b)
    mape = np.mean(abs((a-b)/a))*100
    #F_norm = la.norm(a-b)/la.norm(a)
    #r2 = 1-((a-b)**2).sum()/((a-a.mean())**2).sum()
    #var = 1-(np.var(a - b))/np.var(a)
    # 1-F_norm, r2, var
    return rmse, mae, mape
 
path = r'dataset/PeMSD7_V_228.csv'
data = pd.read_csv(path)

time_len = data.shape[0]   #时间长度为2016个检测点
num_nodes = data.shape[1]   #道路节点个数为207条
train_rate = 0.8   #学习速率为0.8
seq_len = 20
pre_len = 1
trainX,trainY,testX,testY = preprocess_data(data, time_len, train_rate, seq_len, pre_len)
method = 'HA' ####HA or SVR or ARIMA

########### HA #############历史平均法（属于非参数性质的统计学经典方法）
if method == 'HA':
    result = []
    for i in range(len(testX)):   #len(testX)为389
        a = testX[i]   #维度为(12，207)
        a1 = np.mean(a, axis=0)    #维度为(1,207)
        result.append(a1)  #result 为 list ，长度为 389
    result1 = np.array(result)
    result1 = np.reshape(result1, [-1,num_nodes])
    testY1 = np.array(testY)
    testY1 = np.reshape(testY1, [-1,num_nodes])
    #np.save('test.npy',testY1)
    #np.save('pred.npy',result1)
    rmse, mae, mape = evaluation(testY1, result1)  
    print('HA_rmse:%r'%rmse,
          'HA_mae:%r'%mae,
          'HA_mape:%r'%mape,
          )
    '''
    tm = np.mean(testY1,axis=1)
    tpm = np.mean(result1,axis=1)
    tm = tm.tolist()
    tpm = tpm.tolist()
    tm1 = tm[189:189+288]
    tpm1 = tpm[189:189+288]
    dic = pd.DataFrame(tm1,tpm1)
    data = pd.read_csv('G100.csv',header=None,names=['y_true','y_pred'],skiprows=190,nrows=288)
    data1 = pd.read_csv('L100.csv',header=None,names=['y_true','yl_pred'],skiprows=190,nrows=288)
    y_t = data['y_true']
    y_p = data['y_pred']
    y_lp = data1['yl_pred']
    x = [i for i in range(288)]
    plt.plot(x,tm1,label='Ground truth',color='black')
    
    
    plt.plot(x,y_t,label='Ground truth',color='r')
    plt.plot(x,y_p,label='GRU_pred',color='b')
    plt.plot(x,y_lp,label='LSTM_pred',color='y')
    my_x_ticks = np.arange(0, 312, 24)
    plt.xticks(my_x_ticks,('0','2','4','6','8','10','12','14','16','18','20','22','24'))
    plt.legend(loc='lower left')
    plt.title('GL_100')
    plt.xlabel('time')
    plt.ylabel('speed')
    
    plt.show()
    '''

    


############ SVR #############
if method == 'SVR':  
    total_rmse, total_mae, total_acc, result = [], [],[],[]
    for i in range(num_nodes):
        data1 = np.mat(data)
        a = data1[:,i]
        a_X, a_Y, t_X, t_Y = preprocess_data(a, time_len, train_rate, seq_len, pre_len)
        a_X = np.array(a_X)
        a_X = np.reshape(a_X,[-1, seq_len])
        a_Y = np.array(a_Y)
        a_Y = np.reshape(a_Y,[-1, pre_len])
        a_Y = np.mean(a_Y, axis=1)
        t_X = np.array(t_X)
        t_X = np.reshape(t_X,[-1, seq_len])
        t_Y = np.array(t_Y)
        t_Y = np.reshape(t_Y,[-1, pre_len])    
       
        svr_model=SVR(kernel='linear')
        svr_model.fit(a_X, a_Y)
        pre = svr_model.predict(t_X)
        pre = np.array(np.transpose(np.mat(pre)))
        pre = pre.repeat(pre_len ,axis=1)
        result.append(pre)
    result1 = np.array(result)
    result1 = np.reshape(result1, [num_nodes,-1])
    result1 = np.transpose(result1)
    testY1 = np.array(testY)


    testY1 = np.reshape(testY1, [-1,num_nodes])
    total = np.mat(total_acc)
    total[total<0] = 0
    rmse1, mae1, mape = evaluation(testY1, result1)
    print('SVR_rmse:%r'%rmse1,
          'SVR_mae:%r'%mae1,
          'SVR_mape:%r'%mape,)

######## ARIMA #########
if method == 'ARIMA':
    rng = pd.date_range('1/3/2012', periods=5664, freq='15min')
    a1 = pd.DatetimeIndex(rng)
    data.index = a1
    num = data.shape[1]   
    rmse,mae,acc,r2,var,pred,ori = [],[],[],[],[],[],[]
    for i in range(156):
        ts = data.iloc[:,i]
        ts_log=np.log(ts)    
        ts_log=np.array(ts_log,dtype=np.float)
        where_are_inf = np.isinf(ts_log)
        ts_log[where_are_inf] = 0
        ts_log = pd.Series(ts_log)
        ts_log.index = a1
        model = ARIMA(ts_log,order=[1,0,0])
        properModel = model.fit()
        predict_ts = properModel.predict(4, dynamic=True)
        log_recover = np.exp(predict_ts)
        ts = ts[log_recover.index]
        er_rmse,er_mae,er_mape = evaluation(ts,log_recover)
        rmse.append(er_rmse)
        mae.append(er_mae)
        mape.append(er_mape)
#    for i in range(109,num):
#        ts = data.iloc[:,i]
#        ts_log=np.log(ts)    
#        ts_log=np.array(ts_log,dtype=np.float)
#        where_are_inf = np.isinf(ts_log)
#        ts_log[where_are_inf] = 0
#        ts_log = pd.Series(ts_log)
#        ts_log.index = a1
#        model = ARIMA(ts_log,order=[1,1,1])
#        properModel = model.fit(disp=-1, method='css')
#        predict_ts = properModel.predict(2, dynamic=True)
#        log_recover = np.exp(predict_ts)
#        ts = ts[log_recover.index]
#        er_rmse,er_mae,er_acc,r2_score,var_score = evaluation(ts,log_recover)
#        rmse.append(er_rmse)
#        mae.append(er_mae)
#        acc.append(er_acc)  
#        r2.append(r2_score)
#        var.append(var_score)
    #acc1 = np.mat(acc)
    #acc1[acc1 < 0] = 0
    print('arima_rmse:%r'%(np.mean(rmse)),
          'arima_mae:%r'%(np.mean(mae)),
          'arima_mape:%r'%(np.mean(mape))
          )
  
