import os, sys

import logging
from loguru import logger

# 日志文件配置

log_path = os.path.dirname((os.path.abspath(__file__))) + '/logs/'
_log = logger.add(log_path + '{time:YYYY-MM-DD-HH}h.log', format="{time:YYYY-MM-DD at HH:mm} | {level} :{message}",
                  rotation='00:00', retention='15 days', level=logging.INFO)